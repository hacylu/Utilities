This test data has been downloaded from http://openslide.cs.cmu.edu/download/openslide-testdata/.

More test data from various vendors can be found on this site.