#ifndef MATLAB_OPENSLIDE_WRAPPER_H
#define MATLAB_OPENSLIDE_WRAPPER_H
#define OPENSLIDE_SIMPLIFY_HEADERS
#include "C:\Nutstore\Nutstore\PathImAnalysis_Program\Program\Miscellaneous\fordanic-openslide-matlab-502d10a\openslide-win64-20160717\include\openslide\openslide.h"
#endif
